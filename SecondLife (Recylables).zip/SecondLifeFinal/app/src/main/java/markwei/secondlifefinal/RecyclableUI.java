package markwei.secondlifefinal;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class RecyclableUI extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recyclableui);

/*        init();*/
    }

 /*   private void init(){
        Button btnMap = (Button) findViewById(R.id.btnMap);
        btnMap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(RecyclableUI.this, MetalTin.class);
                startActivity(intent);
            }
        });*/
 }
