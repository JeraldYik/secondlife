package com.example.xqlim.secondlife.FavouritesFolder;

import com.example.xqlim.secondlife.MapsFolder.Location;

import java.util.*;

//NOT USED
public class Favourite {
    private ArrayList<Location> favouriteLocations;
}
