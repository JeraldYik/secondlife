package com.example.xqlim.secondlife;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class HistoryManager extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);
    }

    public void viewHistory(){

    }

    public void addHistory(Recyclables recycledItem){

    }

    public void delHistory(Recyclables recycledItem){

    }
}
