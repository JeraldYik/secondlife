package com.example.xqlim.secondlife;

public class Recyclables {
}
