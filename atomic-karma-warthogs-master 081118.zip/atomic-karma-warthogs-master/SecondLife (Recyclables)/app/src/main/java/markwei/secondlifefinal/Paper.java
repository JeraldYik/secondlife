package markwei.secondlifefinal;

public abstract class Paper implements Recyclables{

    public abstract double weight();
    public abstract int quantity();
    public abstract String recyclablerequirements();

}
