package markwei.secondlifefinal;

public abstract class AluminiumDrinkCan implements Recyclables{

    public abstract double weight();
    public abstract int quantity();
    public abstract String recyclablerequirements();

}
