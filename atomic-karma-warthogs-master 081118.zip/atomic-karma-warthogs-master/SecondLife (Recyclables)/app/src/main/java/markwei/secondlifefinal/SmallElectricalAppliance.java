package markwei.secondlifefinal;

public abstract class SmallElectricalAppliance implements Recyclables{

    public abstract double weight();
    public abstract int quantity();
    public abstract String recyclablerequirements();

}
