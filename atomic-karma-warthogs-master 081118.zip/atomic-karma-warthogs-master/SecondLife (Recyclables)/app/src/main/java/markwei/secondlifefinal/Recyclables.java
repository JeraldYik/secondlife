package markwei.secondlifefinal;

public interface Recyclables {

    double weight();
    int quantity();
    String recyclablerequirements();

}
