package com.example.xqlim.secondlife.RecyclablesFolder;

public abstract class CorrugatedCardboard implements Recyclables{

    public abstract double weight();
    public abstract int quantity();
    public abstract String recyclablerequirements();

}
