package com.example.xqlim.secondlife.FavouritesFolder;

import com.example.xqlim.secondlife.MapsFolder.Location;

import java.util.*;

public class Favourite {
    private ArrayList<Location> favouriteLocations;

}
