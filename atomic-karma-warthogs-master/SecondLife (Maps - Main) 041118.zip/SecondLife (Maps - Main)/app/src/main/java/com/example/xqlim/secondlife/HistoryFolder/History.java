package com.example.xqlim.secondlife.HistoryFolder;

import com.example.xqlim.secondlife.RecyclablesFolder.Recyclables;

import java.util.ArrayList;

public class History {
    private ArrayList<Recyclables> recycledItems;
    private int quantityRecycled;
}
