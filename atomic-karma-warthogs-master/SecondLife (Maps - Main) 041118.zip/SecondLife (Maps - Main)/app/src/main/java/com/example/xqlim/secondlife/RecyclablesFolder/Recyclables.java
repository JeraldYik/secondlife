package com.example.xqlim.secondlife.RecyclablesFolder;

public interface Recyclables {

    double weight();
    int quantity();
    String recyclablerequirements();

}
