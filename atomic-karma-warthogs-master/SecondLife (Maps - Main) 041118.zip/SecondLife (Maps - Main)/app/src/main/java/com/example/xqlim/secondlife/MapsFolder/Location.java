package com.example.xqlim.secondlife.MapsFolder;

public class Location {
    private String Name;
    private float Lat;
    private float Long;
    private int openingTime;
    private int closingTime;
    private boolean isFavourite;
}
