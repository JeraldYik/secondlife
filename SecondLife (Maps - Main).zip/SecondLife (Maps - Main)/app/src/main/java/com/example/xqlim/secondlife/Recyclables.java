package com.example.xqlim.secondlife;

public interface Recyclables {

    double weight();
    int quantity();
    String recyclablerequirements();

}
