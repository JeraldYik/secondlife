package com.example.xqlim.secondlife;

public abstract class SecondHandItem implements Recyclables{

    public abstract double weight();
    public abstract int quantity();
    public abstract String recyclablerequirements();

}
