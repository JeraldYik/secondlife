package com.example.xqlim.secondlife;

import java.util.*;

public class Favourite {
    private ArrayList<Location> favouriteLocations;

}
