package com.example.xqlim.secondlife;

import java.util.ArrayList;

public class History {
    private ArrayList<Recyclables> recycledItems;
    private int quantityRecycled;
}
